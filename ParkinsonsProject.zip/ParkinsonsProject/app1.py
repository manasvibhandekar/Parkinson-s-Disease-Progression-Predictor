import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor

df = pd.read_csv("output.csv")
X = df.drop("updrs_1", axis=1)
y = df["updrs_1"]

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.30)

rf = RandomForestRegressor(max_depth=5, random_state=0, n_estimators=50)
rf.fit(X_train, y_train)

st.title("Parkinson's Disease Progression Prediction")

st.sidebar.header("Enter Input Parameters")

# Let user input the values
# input_values = {}
# for feature in X.columns:
#     input_values[feature] = st.sidebar.slider(
#         f"Enter {feature}",
#         float(X[feature].min()),
#         float(X[feature].max()),
#         float(X[feature].mean()),
#     )
input_values = {}
for feature in X.columns:
    input_values[feature] = st.sidebar.text_input(f"Enter {feature}", X[feature].mean())

# Convert user input into DataFrame
user_input_df = pd.DataFrame([input_values])

# Make prediction
prediction = rf.predict(user_input_df)

# Display prediction
st.subheader("Predicted UPDRS Score")
st.write(prediction[0])
