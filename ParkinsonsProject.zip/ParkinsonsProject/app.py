import pandas as pd
import numpy as np

from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

import streamlit as st

df=pd.read_csv('output.csv')
X = df.drop('updrs_1', axis =1)
y = df['updrs_1']


X_train, X_test, y_train, y_test = train_test_split(X, y, 
                                                test_size=0.30)

rf = RandomForestRegressor(max_depth=5, random_state=0,n_estimators=50)
rf.fit(X_train, y_train)




