import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import numpy as np
import os

df = pd.read_csv("output.csv")
X = df.drop("updrs_1", axis=1)
y = df["updrs_1"]


st.sidebar.image("image.png", use_column_width=True)


if "rf" not in st.session_state:

    rf = RandomForestRegressor(max_depth=5, random_state=0, n_estimators=50)
    rf.fit(X, y)

    st.session_state.rf = rf

st.title("Parkinson's Disease Severity Prediction")


detailed_severity_comments = {
    0: "The patient shows minimal or no impairment in motor function. There are no observable symptoms of Parkinson's disease.",
    1: "The patient exhibits mild impairment in motor function. Symptoms are subtle and do not significantly interfere with daily activities.",
    2: "The patient exhibits mild impairment in motor function. Symptoms may be slightly more noticeable but still do not significantly interfere with daily activities.",
    3: "The patient demonstrates moderate impairment in motor function. Symptoms are noticeable and may affect some daily activities.",
    4: "The patient demonstrates moderate impairment in motor function. Symptoms are more pronounced and may interfere with several daily activities.",
    5: "The patient shows moderate to severe impairment in motor function. Symptoms significantly affect daily activities and may require assistance.",
    6: "The patient shows moderate to severe impairment in motor function. Symptoms severely affect daily activities and may require assistance for most tasks.",
    7: "The patient exhibits severe impairment in motor function. Symptoms are profound and significantly limit daily activities.",
    8: "The patient exhibits severe impairment in motor function. Symptoms are debilitating and require substantial assistance for most tasks.",
    9: "The patient exhibits severe impairment in motor function. Symptoms are very severe and render the patient mostly dependent on others for daily activities.",
    10: "The patient exhibits severe impairment in motor function. Symptoms are extremely severe, and the patient is largely incapacitated, requiring full-time assistance.",
}


def add_patient_data_form():
    with st.form(key="patient_data_form"):
        st.subheader("Add New Patient Data")
        patient_name = st.text_input("Patient Name")
        age = st.number_input("Age", min_value=0, max_value=150)
        sex = st.selectbox("Sex", ["Male", "Female"])
        visit_id = st.text_input("Visit ID")

        on_meds_option = ["On", "Off"]
        on_meds = st.selectbox("On Medication", on_meds_option)
        cognitive_impairment_options = [
            "Normal",
            "Mild",
            "Slight",
            "Moderate",
            "Severe",
        ]
        cognitive_impairment = st.selectbox(
            "Cognitive Impairment", cognitive_impairment_options
        )

        hallucinations_and_psychosis_options = [
            "Normal",
            "Mild",
            "Slight",
            "Moderate",
            "Severe",
        ]
        hallucinations_and_psychosis = st.selectbox(
            "Hallucinations and Psychosis", hallucinations_and_psychosis_options
        )

        depressed_mood_options = ["Normal", "Mild", "Slight", "Moderate", "Severe"]
        depressed_mood = st.selectbox("Depressed Mood", depressed_mood_options)

        anxious_mood_options = ["Normal", "Mild", "Slight", "Moderate", "Severe"]
        anxious_mood = st.selectbox("Anxious Mood", anxious_mood_options)

        apathy_options = ["Normal", "Mild", "Slight", "Moderate", "Severe"]
        apathy = st.selectbox("Apathy", apathy_options)

        dopamine_dysregulation_syndrome_features_options = [
            "Normal",
            "Mild",
            "Slight",
            "Moderate",
            "Severe",
        ]
        dopamine_dysregulation_syndrome_features = st.selectbox(
            "Dopamine Dysregulation Syndrome Features",
            dopamine_dysregulation_syndrome_features_options,
        )

        updrs_1 = st.number_input("UPDRS 1", min_value=0)
        updrs_2 = st.number_input("UPDRS 2", min_value=0)
        updrs_3 = st.number_input("UPDRS 3", min_value=0)
        updrs_4 = st.number_input("UPDRS 4", min_value=0)

        submit_button = st.form_submit_button("Submit")

        if submit_button:
            new_row = pd.DataFrame(
                {
                    "Patient Name": [patient_name],
                    "Age": [age],
                    "Gender": [sex],
                    "Visit ID": [visit_id],
                    "On Medication": [on_meds],
                    "Cognitive Impairment": [cognitive_impairment],
                    "Hallucinations and Psychosis": [hallucinations_and_psychosis],
                    "Depressed Mood": [depressed_mood],
                    "Anxious Mood": [anxious_mood],
                    "Apathy": [apathy],
                    "Dopamine Dysregulation Syndrome Features": [
                        dopamine_dysregulation_syndrome_features
                    ],
                    "UPDRS 1": [updrs_1],
                    "UPDRS 2": [updrs_2],
                    "UPDRS 3": [updrs_3],
                    "UPDRS 4": [updrs_4],
                }
            )

            with open("patient_data.csv", "a") as f:
                new_row.to_csv(f, header=f.tell() == 0, index=False)

            st.success("Patient data submitted successfully!")


if st.sidebar.button("Add New Patient Data"):
    add_patient_data_form()


with st.form(key="predict_form"):
    st.subheader("Predict")
    input_values = {}
    for feature in df.columns[:-2]:
        input_values[feature] = st.text_input(f"Enter {feature}", "")
    on_meds_option = ["0", "1"]
    input_values["upd23b_clinical_state_on_medication"] = st.selectbox(
        "On Medication", on_meds_option
    )
    predict_button = st.form_submit_button("Predict")

if predict_button:
    user_input_df = pd.DataFrame([input_values])
    prediction = st.session_state.rf.predict(user_input_df)
    rounded_prediction = round(prediction[0])

    detailed_severity_comment = detailed_severity_comments.get(
        rounded_prediction, "Unknown"
    )

    st.subheader("Predicted UPDRS Score")
    st.write(f"Predicted UPDRS Score: {rounded_prediction}")
    st.subheader("Detailed Severity Comment")
    st.write(detailed_severity_comment)

    with st.form(key="predict_save_form"):
        patient_name_predict = st.text_input("Patient Name", key="predict_patient_name")
        visit_id_predict = st.text_input("Visit ID", key="predict_visit_id")
        submit_predict_button = st.form_submit_button("Submit Prediction")

    if submit_predict_button:
        new_prediction_row = pd.DataFrame(
            {
                "Patient Name": [patient_name_predict],
                "Visit ID": [visit_id_predict],
                "PeptideAbundance": [input_values["PeptideAbundance"]],
                "NPX": [input_values["NPX"]],
                "OnMedication": [input_values["upd23b_clinical_state_on_medication"]],
                "updrs_1": [rounded_prediction],
            }
        )

        with open("result1.csv", "a") as f:
            new_prediction_row.to_csv(f, header=f.tell() == 0, index=False)
        st.success("Prediction submitted successfully!")
